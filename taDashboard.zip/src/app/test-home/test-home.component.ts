import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-home',
  templateUrl: './test-home.component.html',
  styleUrls: ['./test-home.component.css']
})
export class TestHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

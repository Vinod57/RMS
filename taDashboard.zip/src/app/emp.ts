export interface Iemp {
  id:number,
  name:string,
  age:number

}